let player_1 = document.getElementById('box-1')
let player_2 = document.getElementById('box-2')
let player_score1 = document.getElementById('cross')
let player_score2 = document.getElementById('round')
let playerTurn = document.getElementById('turn')
let restartBtn = document.getElementById('button')
let playerText = document.getElementById('showText')
let container = document.getElementById('container')



let player_X = 'X'
let player_O = 'O'
let currentPlayer;
let isGameOver = false;
let selectedPlayer = false
let moves = 0;

let Indicator = getComputedStyle(document.body).getPropertyValue('--winning-blocks')
let winIndicator = getComputedStyle(document.body).getPropertyValue('--orange')

let boxes = Array.from(document.getElementsByClassName('row'))
let spaces = Array(9).fill(null)

console.log(spaces)

function isDraw() {
    return spaces.every((space) => space !== null);
  }
  

// <<< Check Game logic for Which Player Won >>>
function playerHasWon() {

    let winningCombos = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ]
    winningCombos.forEach(e => {
        if ((boxes[e[0]].innerHTML === boxes[e[1]].innerHTML) && (boxes[e[2]].innerHTML == boxes[e[1]].innerHTML) && (boxes[e[0]].innerHTML !== '')) {
            playerText.innerText = `${boxes[e[0]].innerHTML} - Win the Game`
            boxes[e[0]].style.background = winIndicator
            boxes[e[1]].style.background = winIndicator
            boxes[e[2]].style.background = winIndicator
            isGameOver = true;
            
        }

      
    })
}

function checkDrawCondition() {
    if (moves === 9 && !isGameOver) {
      playerText.innerText = "The game ended in a draw!";
      isGameOver = true;
    }

    // console.log(moves)
  }

//  <<< Box Clicked Function >>>
function boxClicked(e) {

    const id = e.target.id
    console.log(id);


    if (!spaces[id]) {
        spaces[id] = currentPlayer
        e.target.innerText = currentPlayer



        // currentPlayer = currentPlayer == player_X ? player_O : player_X
        if (currentPlayer == player_X) {
            currentPlayer = player_O
            playerTurn.innerText = `${currentPlayer} - turn`
        }
        else {
            currentPlayer = player_X
            playerTurn.innerText = `${currentPlayer} - turn`
        }

        moves++
    }

    playerHasWon()
    checkDrawCondition()


}


// <<< Start Game Function >>> 
const startGame = () => {
    boxes.forEach(box => box.addEventListener('click', boxClicked))
}

player_1.addEventListener('click', () => {
    currentPlayer = player_X
    player_1.style.background = Indicator;
    player_2.style.background = ''
    selectedPlayer = true
    startGame()
    isGameOver = false;

})

player_2.addEventListener('click', () => {
    currentPlayer = player_O
    player_2.style.background = Indicator;
    player_1.style.background = ''

    selectedPlayer = true
    startGame()
    isGameOver = false;

})


// <<< Restart Logic for default function >>>
restartBtn.addEventListener('click', () => {
    playerTurn.innerText = 'Select player and start game'
    player_1.style.background = ''
    player_2.style.background = ''
    playerText.innerText = 'Tic Tac Toe'
    

    boxes.forEach(e => {
        e.innerText = ''
        e.style.background = ''
    })

    spaces = Array(9).fill(null)

})
