let player_1 = document.getElementById('box-1')
let player_2 = document.getElementById('box-2')
let X_score = document.getElementById('x_score')
let O_score = document.getElementById('o_score')
let playerTurn = document.getElementById('turn')
let restartBtn = document.getElementById('button')
let playerText = document.getElementById('showText')
let container = document.getElementById('container')
let mode = document.getElementById('mode');
let box = document.getElementById('room')


let player_X = 'X';
let player_O = 'O';
let currentPlayer;
let isGameOver = false;
let selectedPlayer = false;
let moves = 0;
let X_count = 0;
let O_count = 0;


let Indicator = getComputedStyle(document.body).getPropertyValue('--winning-blocks')
let winIndicator = getComputedStyle(document.body).getPropertyValue('--orange')
let dark_mode = getComputedStyle(document.body).getPropertyValue('--dark')
let textColor = getComputedStyle(document.body).getPropertyValue('--textColor')

let boxes = Array.from(document.getElementsByClassName('row'))
let spaces = Array(9).fill(null)

console.log(spaces)

function isDraw() {
    return spaces.every((space) => space !== null);
}


// <<< Check Game logic for Which Player Won >>>
function playerHasWon() {

    let winningCombos = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ]
    winningCombos.forEach(e => {
        if ((boxes[e[0]].innerHTML === boxes[e[1]].innerHTML) && (boxes[e[2]].innerHTML == boxes[e[1]].innerHTML) && (boxes[e[0]].innerHTML !== '')) {
            playerText.innerText = `${boxes[e[0]].innerHTML} - Win the Game`
            boxes[e[0]].style.background = winIndicator
            boxes[e[1]].style.background = winIndicator
            boxes[e[2]].style.background = winIndicator
            isGameOver = true;

            if(boxes[e[0]].innerHTML === player_X){
                X_count++
            }else if(boxes[e[0]].innerHTML === player_O){
                O_count++
            }

            console.log(X_count,O_count)

            X_score.innerText = X_count;
            O_score.innerText = O_count;

        }


    })
}

function checkDrawCondition() {
    if (moves === 9 && !isGameOver) {
        playerText.innerText = "The game ended in a draw!";
        isGameOver = true;
        X_count++
        O_count++
    }
    X_score.innerText = X_count
    O_score.innerText = O_count

    // console.log(moves)
}

//  <<< Box Clicked Function >>>
function boxClicked(e) {

    if (selectedPlayer === true) {

        const id = e.target.id
        console.log(id);


        if (!spaces[id]) {
            spaces[id] = currentPlayer
            e.target.innerText = currentPlayer



            // currentPlayer = currentPlayer == player_X ? player_O : player_X
            if (currentPlayer == player_X) {
                currentPlayer = player_O
                playerTurn.innerText = `${currentPlayer} - turn`
            }
            else {
                currentPlayer = player_X
                playerTurn.innerText = `${currentPlayer} - turn`
            }

            moves++

        }

        playerHasWon()
        checkDrawCondition()

    }else{
        alert('Select Player First')
    }

}


// <<< Start Game Function >>> 

const startGame = () => {
    boxes.forEach(box => box.addEventListener('click', boxClicked))
}

player_1.addEventListener('click', () => {
    currentPlayer = player_X
    player_1.style.background = Indicator;
    player_2.style.background = ''

    isGameOver = false
    selectedPlayer = true
    startGame()


})

player_2.addEventListener('click', () => {
    currentPlayer = player_O
    player_2.style.background = Indicator;
    player_1.style.background = ''

    isGameOver = false
    selectedPlayer = true
    startGame()


})


// <<< Restart Logic for default function >>>
restartBtn.addEventListener('click', () => {
    playerTurn.innerText = 'Select player and start game'
    player_1.style.background = ''
    player_2.style.background = ''
    playerText.innerText = 'Tic Tac Toe'


    boxes.forEach(e => {
        e.innerText = ''
        e.style.background = ''
    })

    spaces = Array(9).fill(null)
    isGameOver = false
    selectedPlayer = false
    moves = 0;
    X_score.innerText = '-'
    O_score.innerText = '-'
    X_count = 0
    O_count = 0

})

mode.addEventListener('click',()=>{
if(mode.innerText === 'Bedtime'){
    mode.innerText = 'light_mode'
    mode.style.color = 'white'
    box.style.background = dark_mode
    // box.style.boxShadow = '5px 5px 20px rgb(208, 103, 208)'
    box.style.color = textColor
    
    document.querySelector('body').style.background = 'black'
    
    // box.style.backdropFilter = 'blur(15px)'

}else{
    mode.innerText = 'Bedtime'
    box.style.background = ''
    box.style.color = ''
    document.querySelector('body').style.background = ''
    mode.style.color = ''
    box.style.backdropFilter = ''
    box.style.boxShadow = ''


}
})